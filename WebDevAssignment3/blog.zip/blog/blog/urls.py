from django.contrib import admin
from django.urls import path
from blog_app.views import PostListView, PostDetailView, post_create

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
  path('admin/', admin.site.urls),
  path('', PostListView.as_view(), name='post_list'),
  path('post/<int:pk>/', PostDetailView.as_view(), name='post_detail'),
  path('post/new/', post_create, name='post_create'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

